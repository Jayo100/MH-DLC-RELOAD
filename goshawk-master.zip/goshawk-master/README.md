[![ko-fi](https://www.ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/R6R21LO82)

# goshawk
Replacement DLC server for 3DS/WiiU Monster Hunter games. 

## Important notice
All DLC files belong to CAPCOM, I take no ownership over them. The sole purpose of this project is the preservation of the DLCs that were served in the WiiU and 3DS systems over the years for the Monster Hunter games.
